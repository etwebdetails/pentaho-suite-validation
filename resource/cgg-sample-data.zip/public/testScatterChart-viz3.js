/*!
 * HITACHI VANTARA PROPRIETARY AND CONFIDENTIAL
 *
 * Copyright 2002 - 2019 Hitachi Vantara. All rights reserved.
 *
 * NOTICE: All information including source code contained herein is, and
 * remains the sole property of Hitachi Vantara and its licensors. The intellectual
 * and technical concepts contained herein are proprietary and confidential
 * to, and are trade secrets of Hitachi Vantara and may be covered by U.S. and foreign
 * patents, or patents in process, and are protected by trade secret and
 * copyright laws. The receipt or possession of this source code and/or related
 * information does not convey or imply any rights to reproduce, disclose or
 * distribute its contents, or to manufacture, use, or sell anything that it
 * may describe, in whole or in part. Any reproduction, modification, distribution,
 * or public display of this information without the express written authorization
 * from Hitachi Vantara is strictly prohibited and in violation of applicable laws and
 * international treaties. Access to the source code contained herein is strictly
 * prohibited to anyone except those individuals and entities who have executed
 * confidentiality and non-disclosure agreements or other agreements with Hitachi Vantara,
 * explicitly covering such access.
 */

/* global params */

(function() {

  lib("cgg-env.js");

  cgg.init();

  // Additional AMD configuration

  var basePathAnalyzer = "/plugin/analyzer/";

  var requireCfg = {
    paths:  {
      "pentaho/analyzer": basePathAnalyzer + "scripts/compressed",
      "pentaho/analyzer/visual/config": basePathAnalyzer + "scripts/visual/config",
      "pentaho/analyzer/resources": basePathAnalyzer + "resources"
    },
    config: {
      "pentaho/environment": {
        application: "pentaho/analyzer"
      },
      "pentaho/modules": {
        "pentaho/analyzer/visual/config": {type: "pentaho/config/spec/IRuleSet"}
      }
    },
    bundles: {
      "pentaho/analyzer/API": [
        "pentaho/analyzer/visual/OptionsAnnotation",
        "pentaho/analyzer/visual/utils"
      ]
    }
  };

  require.config(requireCfg);

  // Template Params BEG
  var typeId = "pentaho/visual/models/Bubble";
  var width = 981;
  var height = 733;
  var dataSpec = /* <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<message id="successGenerateReport" type="success" xmlns="http://www.pentaho.com"/>
 */{"layout":{"meas":["[MEASURE:2]","[MEASURE:0]","[MEASURE:1]"],"rows":["[Department].[Department]"],"cols":["[Region].[Region]"]},"formatStrings":{"[MEASURE:0]":"#,###.00","thousandSeparator":".","decimalPlaceholder":",","[MEASURE:1]":"#,###.00","[MEASURE:2]":"#,###.00","currencySymbol":"\u20ac"},"model":{"format":{"number":{"style":{"currency":"\u20ac","decimal":",","group":"."}}},"attrs":[{"hierarchyOrdinal":0,"members":[{"v":"[Department].[Executive Management]","f":"Executive Management"},{"v":"[Department].[Finance]","f":"Finance"},{"v":"[Department].[Human Resource]","f":"Human Resource"},{"v":"[Department].[Marketing & Communication]","f":"Marketing & Communication"},{"v":"[Department].[Product Development]","f":"Product Development"},{"v":"[Department].[Professional Services]","f":"Professional Services"},{"v":"[Department].[Sales]","f":"Sales"}],"name":"[Department].[Department]","isKey":true,"hierarchyName":"[Department]","label":"Department","type":"string"},{"hierarchyOrdinal":0,"members":[{"p":{"color":"#0000cc"},"v":"[Region].[Central]","f":"Central"},{"p":{"color":"#0d8ecf"},"v":"[Region].[Eastern]","f":"Eastern"},{"p":{"color":"#b0de09"},"v":"[Region].[Southern]","f":"Southern"},{"p":{"color":"#fcd202"},"v":"[Region].[Western]","f":"Western"}],"name":"[Region].[Region]","isKey":true,"hierarchyName":"[Region]","label":"Region","type":"string"},{"p":{"color":"#0000cc"},"isPercent":false,"name":"[MEASURE:0]","format":{"number":{"mask":"#,###.00"}},"label":"Actual","type":"number"},{"p":{"color":"#0d8ecf"},"isPercent":false,"name":"[MEASURE:1]","format":{"number":{"mask":"#,###.00"}},"label":"Budget","type":"number"},{"p":{"color":"#b0de09"},"isPercent":false,"name":"[MEASURE:2]","format":{"number":{"mask":"#,###.00"}},"label":"Variance","type":"number"}]},"rows":[{"c":[{"v":"[Department].[Executive Management]","f":"Executive Management"},{"v":26.736,"f":"267.360,00"},{"v":177.6282,"f":"1.776.282,00"},{"v":2043.642,"f":"2.043.642,00"},{"v":-2.4072,"f":"-24.072,00"},{"v":150.758,"f":"1.507.580,00"},{"v":1483.508,"f":"1.483.508,00"},{"v":1.5928,"f":"15.928,00"},{"v":150.758,"f":"1.507.580,00"},{"v":1523.508,"f":"1.523.508,00"},{"v":-6.4072,"f":"-64.072,00"},{"v":150.758,"f":"1.507.580,00"},{"v":1443.508,"f":"1.443.508,00"}]},{"c":[{"v":"[Department].[Finance]","f":"Finance"},{"v":-3.9319,"f":"-39.319,00"},{"v":310.668,"f":"3.106.680,00"},{"v":3067.361,"f":"3.067.361,00"},{"v":-2.9165,"f":"-29.165,00"},{"v":303.918,"f":"3.039.180,00"},{"v":3010.015,"f":"3.010.015,00"},{"v":-2.9165,"f":"-29.165,00"},{"v":303.918,"f":"3.039.180,00"},{"v":3010.015,"f":"3.010.015,00"},{"v":-3.9165,"f":"-39.165,00"},{"v":303.918,"f":"3.039.180,00"},{"v":3000.015,"f":"3.000.015,00"}]},{"c":[{"v":"[Department].[Human Resource]","f":"Human Resource"},{"v":-2.4568,"f":"-24.568,00"},{"v":343.8863,"f":"3.438.863,00"},{"v":3414.295,"f":"3.414.295,00"},{"v":-1.6518,"f":"-16.518,00"},{"v":321.22,"f":"3.212.200,00"},{"v":3195.682,"f":"3.195.682,00"},{"v":-1.6518,"f":"-16.518,00"},{"v":321.22,"f":"3.212.200,00"},{"v":3195.682,"f":"3.195.682,00"},{"v":-2.8518,"f":"-28.518,00"},{"v":321.22,"f":"3.212.200,00"},{"v":3183.682,"f":"3.183.682,00"}]},{"c":[{"v":"[Department].[Marketing & Communication]","f":"Marketing & Communication"},{"v":-0.7871,"f":"-7.871,00"},{"v":359.0423,"f":"3.590.423,00"},{"v":3582.552,"f":"3.582.552,00"},{"v":-5.6205,"f":"-56.205,00"},{"v":344.011,"f":"3.440.110,00"},{"v":3383.905,"f":"3.383.905,00"},{"v":-3.8205,"f":"-38.205,00"},{"v":344.011,"f":"3.440.110,00"},{"v":3401.905,"f":"3.401.905,00"},{"v":-3.8205,"f":"-38.205,00"},{"v":344.011,"f":"3.440.110,00"},{"v":3401.905,"f":"3.401.905,00"}]},{"c":[{"v":"[Department].[Product Development]","f":"Product Development"},{"v":16.1478,"f":"161.478,00"},{"v":299.7702,"f":"2.997.702,00"},{"v":3159.18,"f":"3.159.180,00"},{"v":-1.8323,"f":"-18.323,00"},{"v":254.88,"f":"2.548.800,00"},{"v":2530.477,"f":"2.530.477,00"},{"v":-0.0323,"f":"-323,00"},{"v":254.88,"f":"2.548.800,00"},{"v":2548.477,"f":"2.548.477,00"},{"v":-0.0323,"f":"-323,00"},{"v":254.88,"f":"2.548.800,00"},{"v":2548.477,"f":"2.548.477,00"}]},{"c":[{"v":"[Department].[Professional Services]","f":"Professional Services"},{"v":33.1961,"f":"331.961,00"},{"v":2006.8039,"f":"20.068.039,00"},{"v":20400,"f":"20.400.000,00"},{"v":35.013,"f":"350.130,00"},{"v":1874.987,"f":"18.749.870,00"},{"v":19100,"f":"19.100.000,00"},{"v":-35.987,"f":"-359.870,00"},{"v":1874.987,"f":"18.749.870,00"},{"v":18390,"f":"18.390.000,00"},{"v":-54.1664,"f":"-541.664,00"},{"v":1874.987,"f":"18.749.870,00"},{"v":18208.206,"f":"18.208.206,00"}]},{"c":[{"v":"[Department].[Sales]","f":"Sales"},{"v":-18.4603,"f":"-184.603,00"},{"v":291.5173,"f":"2.915.173,00"},{"v":2730.57,"f":"2.730.570,00"},{"v":3.3074,"f":"33.074,00"},{"v":275.12,"f":"2.751.200,00"},{"v":2784.274,"f":"2.784.274,00"},{"v":-1.6926,"f":"-16.926,00"},{"v":275.12,"f":"2.751.200,00"},{"v":2734.274,"f":"2.734.274,00"},{"v":-2.6926,"f":"-26.926,00"},{"v":275.12,"f":"2.751.200,00"},{"v":2724.274,"f":"2.724.274,00"}]}],"version":3,"cols":[{"dataReq":[{"level":"[Department].[Department]","id":"rows"}],"id":"[Department].[Department]","label":"Department","attr":"[Department].[Department]","type":"string"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"size"}],"c":["[Region].[Central]"],"id":"[Region].[Central]~[MEASURE:2]","label":"Central~Variance","attr":"[MEASURE:2]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"x"}],"c":["[Region].[Central]"],"id":"[Region].[Central]~[MEASURE:0]","label":"Central~Actual","attr":"[MEASURE:0]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"y"}],"c":["[Region].[Central]"],"id":"[Region].[Central]~[MEASURE:1]","label":"Central~Budget","attr":"[MEASURE:1]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"size"}],"c":["[Region].[Eastern]"],"id":"[Region].[Eastern]~[MEASURE:2]","label":"Eastern~Variance","attr":"[MEASURE:2]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"x"}],"c":["[Region].[Eastern]"],"id":"[Region].[Eastern]~[MEASURE:0]","label":"Eastern~Actual","attr":"[MEASURE:0]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"y"}],"c":["[Region].[Eastern]"],"id":"[Region].[Eastern]~[MEASURE:1]","label":"Eastern~Budget","attr":"[MEASURE:1]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"size"}],"c":["[Region].[Southern]"],"id":"[Region].[Southern]~[MEASURE:2]","label":"Southern~Variance","attr":"[MEASURE:2]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"x"}],"c":["[Region].[Southern]"],"id":"[Region].[Southern]~[MEASURE:0]","label":"Southern~Actual","attr":"[MEASURE:0]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"y"}],"c":["[Region].[Southern]"],"id":"[Region].[Southern]~[MEASURE:1]","label":"Southern~Budget","attr":"[MEASURE:1]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"size"}],"c":["[Region].[Western]"],"id":"[Region].[Western]~[MEASURE:2]","label":"Western~Variance","attr":"[MEASURE:2]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"x"}],"c":["[Region].[Western]"],"id":"[Region].[Western]~[MEASURE:0]","label":"Western~Actual","attr":"[MEASURE:0]","type":"number"},{"dataReq":[{"level":"[Region].[Region]","id":"color"},{"level":"[Measures].[MeasuresLevel]","id":"y"}],"c":["[Region].[Western]"],"id":"[Region].[Western]~[MEASURE:1]","label":"Western~Budget","attr":"[MEASURE:1]","type":"number"}],"colors":{"[Region].[Region]":{"[Region].[Central]":"#0000cc","[Region].[Southern]":"#b0de09","[Region].[Eastern]":"#0d8ecf","[Region].[Western]":"#fcd202"},"[Measures].[MeasuresLevel]":{"[MEASURE:0]":"#0000cc","[MEASURE:1]":"#0d8ecf","[MEASURE:2]":"#b0de09"}}};
  var pluginData = [{"labelsOption":"right","trendType":"none","trendName":"","trendLineWidth":3}];
  var chartOptions = {"labelFontFamily":"Default","legendFontFamily":"Arial Narrow","showLegend":"true","legendStyle":"PLAIN","autoRange":"true","maxValues":"2500","valueAxisUpperLimitSecondary":"5000.0","lineShape":"CIRCLE","lineWidth":"2","labelSize":"12","valueAxisUpperLimit":"0.5","backgroundColorEnd":"#ffffff","labelStyle":"PLAIN","autoRangeSecondary":"true","legendColor":"#000000","backgroundFill":"SOLID","valueAxisLowerLimit":"0.0","backgroundColor":"#ffffe0","displayUnitsSecondary":"UNITS_3","multiChartRangeScope":"GLOBAL","sizeByNegativesMode":"USE_ABS","maxChartsPerRow":"5","legendSize":"18","labelColor":"#000000","valueAxisLowerLimitSecondary":"0.0","customChartType":"pentaho/visual/models/Bubble","legendBackgroundColor":"#ffffff","chartType":"CUSTOM","displayUnits":"UNITS_4","emptyCellMode":"GAP","legendPosition":"TOP","vizApiVersion":"3.0"};
  var visualMap = {"color":["[Region].[Region]"],"size":["[MEASURE:2]"],"x":["[MEASURE:0]"],"y":["[MEASURE:1]"],"rows":["[Department].[Department]"]};
  // Template Params END

  require([
    "cdf/lib/CCC/def",
    "pentaho/data/Table",
    "pentaho/visual/util",
    "pentaho/analyzer/visual/utils",
    "pentaho/visual/ModelAdapter"
  ], function(def, Table, visualUtil, localVisualUtils, ModelAdapter) {

    try {
      def.setDebug(cgg.debug);

      var domContainer = document.documentElement;

      // Specify dimensions in the wrapper's dom element.
      domContainer.setAttribute("width",  String(width));
      domContainer.setAttribute("height", String(height));

      var view;
      var model;

      visualUtil.getModelAndDefaultViewClassesAsync(typeId)
        .then(function(classes) {
          model = createModel(classes.Model);
          var modelAdapter = createModelAdapter(model, ModelAdapter);

          view = new classes.View({
            model: model,
            domContainer: domContainer
          });

          return model.update();
        })
        .then(function() {
          // Set the SVG element with the final/grown chart width/height
          // so that the PNGTranscoder can detect the actual image size.
          var cccChart  = view._chart;
          var basePanel = cccChart && cccChart.basePanel;

          domContainer.setAttribute("width", String(basePanel ? basePanel.width : model.width));
          domContainer.setAttribute("height", String(basePanel ? basePanel.height : model.height));
        })
        ["catch"](function(ex) {
          print(ex.message + ex.stack);
        });

    } catch(ex) {
      print(ex.message + ex.stack);
    }

    function createModel(VizModel) {

      var modelSpec = pluginData[0] || {};

      modelSpec.isAutoUpdate = false;
      modelSpec.width = width;
      modelSpec.height = height;

      // Mixin Chart Options
      def.copyOwn(modelSpec, generateModelPropsImplied(VizModel.type));

      // CCC wrapper specific CGG option
      var multiChartOverflow = params.get("multiChartOverflow");
      if(multiChartOverflow)
        modelSpec.multiChartOverflow = multiChartOverflow.toLowerCase();

      return new VizModel(modelSpec);
    }

    function createModelAdapter(model, BaseVizModelAdapter) {

      // Create the class dynamically.
      var VizModelAdapter = BaseVizModelAdapter.extend({
        $type: {
          props: {
            model: {valueType: model.constructor}
          }
        }
      });

      var modelAdapterSpec = {
        model: model,
        data: new Table(dataSpec)
      };

      addVisualRoleMappingsToVisualSpec(VizModelAdapter.type, modelAdapterSpec);

      return new VizModelAdapter(modelAdapterSpec);
    }

    function generateModelPropsImplied(modelType) {

      var vizProps;
      var annotationSpec = localVisualUtils.getVizOptionsAnnotation(modelType.id);
      var handler = annotationSpec && annotationSpec.generateOptionsFromAnalyzerState;
      if(handler) {
        vizProps = handler(getReportMock());
      }

      return vizProps || {};
    }

    function getReportMock() {

      var attrs = [];

      for(var p in chartOptions) {
        if(def.hasOwn(chartOptions, p)) {
          attrs.push({
            nodeName:  p,
            nodeValue: chartOptions[p]
          });
        }
      }

      return {
        reportDoc: {
          getChartOptions: function() {
            return {attributes: attrs};
          }
        }
      };
    }

    function addVisualRoleMappingsToVisualSpec(modelAdapterType, spec) {
      modelAdapterType.eachVisualRole(function(propType) {
        var name = propType.name;
        spec[name] = {fields: visualMap[name] || []};
      });
    }

  }, function(ex) {
    print(ex.message + ex.stack);
  });

  // Process any async tasks installed by setTimeout
  cgg.run();

}());
